#pragma once


#define SCREEN_WIDTH 1920
#define SCREEN_HEIGHT 1080